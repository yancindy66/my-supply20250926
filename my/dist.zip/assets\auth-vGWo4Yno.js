import{n as r}from"./index-DCT-9Cky.js";async function n(o){const t=await r.post("/api/auth/login",o);if(t?.code===0)return t.data;throw new Error(t?.msg||"登录失败")}export{n as l};
